import img1 from "../img/1.png";
import img2 from "../img/2.png";
import img3 from "../img/3.png";
import img4 from "../img/4.png";
import img5 from "../img/5.png";

export const testimonials_data = [
	{
		img: img1,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Rovert Downy jr`,
		designation: `The Iron man and CEO`,
	},
	{
		img: img2,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Md Anwar Hossain`,
		designation: `The Iron man and CEO`,
	},
	{
		img: img3,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Md. Ziaul Haque Polash`,
		designation: `The Iron man and CEO`,
	},
	{
		img: img4,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Ravindra Jadeja`,
		designation: `The Iron man and CEO`,
	},
	{
		img: img5,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Tony Kukkar`,
		designation: `The Iron man and CEO`,
	},
	{
		img: img1,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Rovert Downy jr`,
		designation: `The Iron man and CEO`,
	},
	{
		img: img2,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Md Anwar Hossain`,
		designation: `The Iron man and CEO`,
	},
	{
		img: img3,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Md. Ziaul Haque Polash`,
		designation: `The Iron man and CEO`,
	},
	{
		img: img4,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Ravindra Jadeja`,
		designation: `The Iron man and CEO`,
	},
	{
		img: img5,
		quote: `Lorem ipsum dolor sit amet, consectetur adipiscing elit. Odio amet
				turpis tincidunt posuere aliquam et. Ac adipiscing sed eros.`,
		name: `Tony Kukkar`,
		designation: `The Iron man and CEO`,
	},
];
