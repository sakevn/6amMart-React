export const CustomHeader = {
  "X-software-id": 33571750,
  "X-server": "server",
  origin: process.env.NEXT_CLIENT_HOST_URL,
};
