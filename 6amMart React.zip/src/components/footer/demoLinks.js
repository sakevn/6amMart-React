export const RouteLinksData = [
  {
    name: "Become a store owner",
    value: "restaurant_owner",
    link: "/store-registration",
  },
  {
    name: "Become a delivery man",
    value: "delivery_man",
    link: "/deliveryman-registration",
  },
  {
    name: "Help & Support",
    value: "help-and-support",
    link: "/help-and-support",
  },
];
